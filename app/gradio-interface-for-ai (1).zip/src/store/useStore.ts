import { create } from 'zustand';
import type { Session } from '../types';
import type { EpochRecord, ClassDist, InferenceResult } from '../api/client';

interface AnalyticsData {
  epochHistory: EpochRecord[];
  trainDistribution: ClassDist[];
  validDistribution: ClassDist[];
  testResult: InferenceResult | null;
}

interface AppState {
  session: Session | null;
  analytics: AnalyticsData;
  setSession: (s: Session | null) => void;
  setAnalytics: (a: Partial<AnalyticsData>) => void;
  setTestResult: (r: InferenceResult | null) => void;
}

export const useStore = create<AppState>((set) => ({
  session: null,
  analytics: {
    epochHistory: [],
    trainDistribution: [],
    validDistribution: [],
    testResult: null,
  },
  setSession: (session) => set({ session }),
  setAnalytics: (a) =>
    set((state) => ({ analytics: { ...state.analytics, ...a } })),
  setTestResult: (testResult) =>
    set((state) => ({ analytics: { ...state.analytics, testResult } })),
}));
