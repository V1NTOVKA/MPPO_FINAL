// Persistent local DB using localStorage
// Used as fallback when backend (Docker) is not available.
import type { User } from '../types';

const DB_KEY = 'galactic_db_users_v2';

const defaultAdmin: User = {
  id: 'admin-001',
  username: 'admin',
  password: 'admin123',
  firstName: 'Михаил',
  lastName: 'Администратов',
  role: 'admin',
  createdAt: new Date().toISOString(),
};

export function initDB(): void {
  if (!localStorage.getItem(DB_KEY)) {
    localStorage.setItem(DB_KEY, JSON.stringify([defaultAdmin]));
  }
}

export function getAllUsers(): User[] {
  const raw = localStorage.getItem(DB_KEY);
  if (!raw) {
    initDB();
    return [defaultAdmin];
  }
  try {
    return JSON.parse(raw) as User[];
  } catch {
    return [defaultAdmin];
  }
}

export function getUserByUsername(username: string): User | null {
  return getAllUsers().find((u) => u.username === username) ?? null;
}

/** Validate username + plaintext password against stored record. */
export function getUserByCredentials(username: string, password: string): User | null {
  const user = getUserByUsername(username);
  if (!user) return null;
  // Compare plaintext (localStorage) — backend uses sha256
  if (user.password !== password) return null;
  return user;
}

export function createUser(user: User): void {
  const users = getAllUsers();
  users.push(user);
  localStorage.setItem(DB_KEY, JSON.stringify(users));
}

export function deleteUser(id: string): void {
  const users = getAllUsers().filter((u) => u.id !== id);
  localStorage.setItem(DB_KEY, JSON.stringify(users));
}
