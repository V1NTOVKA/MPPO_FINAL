import { useState, useEffect, useCallback } from 'react';
import { api } from '../api/client';
import { UserPlus, Trash2, Users, CheckCircle, AlertCircle, Loader2 } from 'lucide-react';

interface UserRow {
  id: string; username: string; first_name: string; last_name: string;
  role: string; created_at: string;
}

const CARD  = { background: 'rgba(255,255,255,0.025)', border: '1px solid rgba(255,255,255,0.07)', borderRadius: 16 };
const INPUT = {
  background: 'rgba(255,255,255,0.05)',
  border: '1px solid rgba(255,255,255,0.09)',
  borderRadius: 10, color: '#e2e4e9', outline: 'none',
  padding: '8px 14px', fontSize: 14, width: '100%',
};

export function AdminUsersPage() {
  const [users, setUsers]     = useState<UserRow[]>([]);
  const [form, setForm]       = useState({ username: '', password: '', firstName: '', lastName: '' });
  const [error, setError]     = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);
  const [listLoading, setListLoading] = useState(true);

  const reload = useCallback(async () => {
    try {
      setListLoading(true);
      const rows = await api.listUsers();
      setUsers(rows);
    } catch { /* ignore */ }
    finally { setListLoading(false); }
  }, []);

  useEffect(() => { reload(); }, [reload]);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(''); setSuccess('');
    if (!form.username || !form.password || !form.firstName || !form.lastName) {
      setError('Заполните все поля'); return;
    }
    setLoading(true);
    try {
      await api.createUser(form);
      await reload();
      setForm({ username: '', password: '', firstName: '', lastName: '' });
      setSuccess(`Пользователь ${form.firstName} ${form.lastName} создан`);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Ошибка при создании');
    } finally { setLoading(false); }
  };

  const handleDelete = async (id: string) => {
    try { await api.deleteUser(id); await reload(); }
    catch (err: unknown) { alert(err instanceof Error ? err.message : 'Ошибка'); }
  };

  const Field = ({ label, field, type = 'text', placeholder }: {
    label: string; field: keyof typeof form; type?: string; placeholder: string;
  }) => (
    <div>
      <label className="block text-xs mb-1.5" style={{ color: '#6b7280' }}>{label}</label>
      <input
        type={type}
        value={form[field]}
        onChange={(e) => setForm({ ...form, [field]: e.target.value })}
        placeholder={placeholder}
        style={INPUT}
        onFocus={e => ((e.target as HTMLInputElement).style.borderColor = 'rgba(129,140,248,0.35)')}
        onBlur={e => ((e.target as HTMLInputElement).style.borderColor = 'rgba(255,255,255,0.09)')}
      />
    </div>
  );

  return (
    <div className="space-y-6 max-w-3xl">

      {/* Create user */}
      <div className="p-6" style={CARD}>
        <div className="flex items-center gap-2.5 mb-5">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
            style={{ background: 'rgba(99,102,241,0.1)', border: '1px solid rgba(99,102,241,0.15)' }}>
            <UserPlus className="w-4 h-4" style={{ color: '#818cf8' }} />
          </div>
          <div>
            <h3 className="text-sm font-semibold" style={{ color: '#c9cbd0' }}>Создать пользователя</h3>
            <p className="text-xs" style={{ color: '#4b5563' }}>Все поля обязательны</p>
          </div>
        </div>

        <form onSubmit={handleCreate} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="Имя"     field="firstName" placeholder="Иван" />
          <Field label="Фамилия" field="lastName"  placeholder="Иванов" />
          <Field label="Логин"   field="username"  placeholder="ivan_ivanov" />
          <Field label="Пароль"  field="password"  type="password" placeholder="••••••••" />

          <div className="sm:col-span-2 space-y-3">
            {error && (
              <div className="flex items-center gap-2 rounded-lg px-3.5 py-2.5 text-sm"
                style={{ background: 'rgba(220,38,38,0.08)', border: '1px solid rgba(220,38,38,0.14)', color: '#f87171' }}>
                <AlertCircle className="w-4 h-4 flex-shrink-0" /> {error}
              </div>
            )}
            {success && (
              <div className="flex items-center gap-2 rounded-lg px-3.5 py-2.5 text-sm"
                style={{ background: 'rgba(34,197,94,0.07)', border: '1px solid rgba(34,197,94,0.13)', color: '#4ade80' }}>
                <CheckCircle className="w-4 h-4 flex-shrink-0" /> {success}
              </div>
            )}
            <button type="submit" disabled={loading}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all"
              style={{
                background: 'rgba(99,102,241,0.12)',
                border: '1px solid rgba(99,102,241,0.2)',
                color: '#a5b4fc',
                cursor: loading ? 'not-allowed' : 'pointer',
                opacity: loading ? 0.6 : 1,
              }}>
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <UserPlus className="w-4 h-4" />}
              Создать пользователя
            </button>
          </div>
        </form>
      </div>

      {/* Users list */}
      <div style={{ ...CARD, overflow: 'hidden' }}>
        <div className="flex items-center gap-2.5 px-5 py-4"
          style={{ borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
          <Users className="w-4 h-4" style={{ color: '#6b7280' }} />
          <h3 className="text-sm font-semibold" style={{ color: '#c9cbd0' }}>Пользователи</h3>
          <span className="ml-auto rounded-full px-2.5 py-0.5 text-xs"
            style={{ background: 'rgba(99,102,241,0.1)', color: '#818cf8' }}>
            {users.length}
          </span>
        </div>

        {listLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-5 h-5 animate-spin" style={{ color: '#4b5563' }} />
          </div>
        ) : (
          <div className="divide-y" style={{ borderColor: 'rgba(255,255,255,0.05)' }}>
            {users.map((u) => (
              <div key={u.id} className="flex items-center gap-4 px-5 py-3.5">
                <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold flex-shrink-0"
                  style={{ background: 'rgba(99,102,241,0.12)', color: '#818cf8' }}>
                  {u.first_name[0]}{u.last_name[0]}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate" style={{ color: '#c9cbd0' }}>
                    {u.first_name} {u.last_name}
                  </p>
                  <p className="text-xs truncate" style={{ color: '#4b5563' }}>@{u.username}</p>
                </div>
                <span className="text-xs px-2 py-0.5 rounded-full flex-shrink-0"
                  style={u.role === 'admin'
                    ? { background: 'rgba(139,92,246,0.1)', color: '#a78bfa', border: '1px solid rgba(139,92,246,0.15)' }
                    : { background: 'rgba(255,255,255,0.04)', color: '#4b5563', border: '1px solid rgba(255,255,255,0.07)' }}>
                  {u.role === 'admin' ? 'Администратор' : 'Пользователь'}
                </span>
                <span className="text-xs flex-shrink-0 hidden sm:block" style={{ color: '#374151' }}>
                  {new Date(u.created_at).toLocaleDateString('ru-RU')}
                </span>
                {u.id !== 'admin-001' && (
                  <button onClick={() => handleDelete(u.id)}
                    className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 transition-all"
                    style={{ color: '#4b5563' }}
                    onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = 'rgba(220,38,38,0.1)'; (e.currentTarget as HTMLButtonElement).style.color = '#f87171'; }}
                    onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = 'transparent'; (e.currentTarget as HTMLButtonElement).style.color = '#4b5563'; }}>
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
