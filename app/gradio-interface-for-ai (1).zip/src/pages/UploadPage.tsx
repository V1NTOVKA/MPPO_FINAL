import { useState, useRef } from 'react';
import { useStore } from '../store/useStore';
import { api } from '../api/client';
import { Upload, FileArchive, CheckCircle, AlertCircle, TrendingUp, TrendingDown, Info, Cpu } from 'lucide-react';

const CARD = { background: 'rgba(255,255,255,0.025)', border: '1px solid rgba(255,255,255,0.07)', borderRadius: 16 };
const LABEL = { color: '#6b7280' };

export function UploadPage({ onGoAnalytics }: { onGoAnalytics: () => void }) {
  const setTestResult = useStore((s) => s.setTestResult);
  const testResult    = useStore((s) => s.analytics.testResult);
  const [dragging, setDragging]   = useState(false);
  const [file, setFile]           = useState<File | null>(null);
  const [loading, setLoading]     = useState(false);
  const [progress, setProgress]   = useState(0);
  const [error, setError]         = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFile = async (f: File) => {
    if (!f.name.endsWith('.npz')) {
      setError('Пожалуйста, загрузите файл в формате .npz');
      return;
    }
    setError('');
    setFile(f);
    setLoading(true);
    setProgress(0);

    // Animate progress
    const tick = setInterval(() => setProgress((p) => Math.min(p + 3, 85)), 120);

    try {
      const result = await api.runInference(f);
      clearInterval(tick);
      setProgress(100);
      await new Promise((r) => setTimeout(r, 300));
      setTestResult(result);
    } catch (err: unknown) {
      clearInterval(tick);
      setError(err instanceof Error ? err.message : 'Ошибка при обработке файла');
    } finally {
      setLoading(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    const f = e.dataTransfer.files[0];
    if (f) handleFile(f);
  };



  return (
    <div className="space-y-6 max-w-2xl">

      {/* Info banner */}
      <div className="flex items-start gap-3 rounded-xl px-4 py-3.5"
        style={{ background: 'rgba(99,102,241,0.06)', border: '1px solid rgba(99,102,241,0.14)' }}>
        <Info className="w-4 h-4 flex-shrink-0 mt-0.5" style={{ color: '#818cf8' }} />
        <div className="text-sm" style={{ color: '#9ca3af' }}>
          <p className="font-medium mb-0.5" style={{ color: '#c5c7d0' }}>Формат тестового набора данных</p>
          <p>
            Загрузите архив <code className="px-1 rounded text-xs" style={{ background: 'rgba(255,255,255,0.06)', color: '#a5b4fc' }}>.npz</code> с массивами&nbsp;
            <code className="px-1 rounded text-xs" style={{ background: 'rgba(255,255,255,0.06)', color: '#a5b4fc' }}>test_x</code> (WAV-сигналы) и&nbsp;
            <code className="px-1 rounded text-xs" style={{ background: 'rgba(255,255,255,0.06)', color: '#a5b4fc' }}>test_y</code> (классы).
            Модель выполнит классификацию и отобразит результаты.
          </p>
        </div>
      </div>

      {/* Drop zone */}
      <div
        className="relative rounded-2xl p-12 text-center cursor-pointer transition-all"
        style={{
          border: dragging
            ? '2px dashed rgba(129,140,248,0.5)'
            : '2px dashed rgba(255,255,255,0.09)',
          background: dragging ? 'rgba(99,102,241,0.05)' : 'rgba(255,255,255,0.015)',
        }}
        onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
        onDragLeave={() => setDragging(false)}
        onDrop={handleDrop}
        onClick={() => !loading && inputRef.current?.click()}
      >
        <input ref={inputRef} type="file" accept=".npz" className="hidden"
          onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFile(f); }} />

        {loading ? (
          <div className="space-y-4">
            <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl"
              style={{ background: 'rgba(99,102,241,0.1)', border: '1px solid rgba(99,102,241,0.15)' }}>
              <Cpu className="w-7 h-7" style={{ color: '#818cf8' }} />
            </div>
            <div>
              <p className="font-medium text-sm" style={{ color: '#c9cbd0' }}>Выполняется инференс модели...</p>
              <p className="text-xs mt-1" style={{ color: '#4b5563' }}>Модель классифицирует сигналы</p>
            </div>
            <div className="w-48 mx-auto rounded-full overflow-hidden h-1"
              style={{ background: 'rgba(255,255,255,0.06)' }}>
              <div className="h-full rounded-full transition-all duration-300"
                style={{ width: `${progress}%`, background: 'rgba(129,140,248,0.6)' }} />
            </div>
            <p className="text-xs" style={{ color: '#4b5563' }}>{progress}%</p>
          </div>
        ) : (
          <div className="space-y-3">
            <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl"
              style={{
                background: file && testResult ? 'rgba(34,197,94,0.08)' : 'rgba(255,255,255,0.04)',
                border: `1px solid ${file && testResult ? 'rgba(34,197,94,0.15)' : 'rgba(255,255,255,0.08)'}`,
              }}>
              {file && testResult
                ? <CheckCircle className="w-7 h-7" style={{ color: '#4ade80' }} />
                : <FileArchive className="w-7 h-7" style={{ color: '#4b5563' }} />
              }
            </div>
            <div>
              <p className="text-sm font-medium" style={{ color: '#c9cbd0' }}>
                {file && testResult ? file.name : 'Перетащите .npz файл или нажмите для выбора'}
              </p>
              <p className="text-xs mt-0.5" style={{ color: '#4b5563' }}>
                {file && testResult ? 'Файл успешно обработан' : 'Поддерживается формат .npz'}
              </p>
            </div>
            {!testResult && (
              <button className="inline-flex items-center gap-2 px-5 py-2 rounded-xl text-sm font-medium transition-all"
                style={{
                  background: 'rgba(99,102,241,0.12)',
                  border: '1px solid rgba(99,102,241,0.2)',
                  color: '#a5b4fc',
                }}>
                <Upload className="w-4 h-4" />
                Выбрать файл
              </button>
            )}
          </div>
        )}
      </div>

      {error && (
        <div className="flex items-center gap-2 rounded-xl px-4 py-3 text-sm"
          style={{ background: 'rgba(220,38,38,0.08)', border: '1px solid rgba(220,38,38,0.15)', color: '#f87171' }}>
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          {error}
        </div>
      )}

      {/* Results */}
      {testResult && !loading && (
        <div className="space-y-5">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold" style={{ color: '#c9cbd0' }}>Результаты тестирования</h3>
            {testResult.realInference && (
              <span className="text-xs px-2 py-1 rounded-full"
                style={{ background: 'rgba(34,197,94,0.08)', border: '1px solid rgba(34,197,94,0.15)', color: '#4ade80' }}>
                Реальный инференс
              </span>
            )}
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div className="rounded-xl p-4" style={CARD}>
              <div className="flex items-center gap-1.5 mb-2">
                <TrendingUp className="w-3.5 h-3.5" style={{ color: '#4ade80' }} />
                <span className="text-xs" style={LABEL}>Accuracy</span>
              </div>
              <p className="text-2xl font-semibold" style={{ color: '#4ade80' }}>
                {(testResult.accuracy * 100).toFixed(2)}%
              </p>
            </div>

            <div className="rounded-xl p-4" style={CARD}>
              <div className="flex items-center gap-1.5 mb-2">
                <TrendingDown className="w-3.5 h-3.5" style={{ color: '#f59e0b' }} />
                <span className="text-xs" style={LABEL}>Loss</span>
              </div>
              <p className="text-2xl font-semibold" style={{ color: '#f59e0b' }}>
                {testResult.loss.toFixed(4)}
              </p>
            </div>

            <div className="rounded-xl p-4" style={CARD}>
              <div className="flex items-center gap-1.5 mb-2">
                <FileArchive className="w-3.5 h-3.5" style={{ color: '#818cf8' }} />
                <span className="text-xs" style={LABEL}>Записей</span>
              </div>
              <p className="text-2xl font-semibold" style={{ color: '#a5b4fc' }}>
                {testResult.totalSamples}
              </p>
            </div>
          </div>

          {/* Per-class summary */}
          <div className="rounded-2xl p-5" style={CARD}>
            <h4 className="text-xs font-medium mb-3" style={{ color: '#6b7280' }}>Точность по цивилизациям</h4>
            <div className="space-y-2">
              {testResult.perClassAccuracy.map((cls) => (
                <div key={cls.classId} className="flex items-center gap-3">
                  <span className="text-xs w-24 truncate flex-shrink-0" style={{ color: '#9ca3af' }}>
                    {cls.className}
                  </span>
                  <div className="flex-1 h-1.5 rounded-full overflow-hidden"
                    style={{ background: 'rgba(255,255,255,0.05)' }}>
                    <div className="h-full rounded-full transition-all"
                      style={{
                        width: `${cls.accuracy * 100}%`,
                        background: cls.accuracy >= 0.9
                          ? 'rgba(74,222,128,0.5)'
                          : cls.accuracy >= 0.75
                          ? 'rgba(251,191,36,0.5)'
                          : 'rgba(248,113,113,0.5)',
                      }} />
                  </div>
                  <span className="text-xs w-12 text-right flex-shrink-0" style={{ color: '#6b7280' }}>
                    {(cls.accuracy * 100).toFixed(1)}%
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="flex gap-3">
            <button
              onClick={() => { setFile(null); setTestResult(null); }}
              className="flex-1 py-2.5 rounded-xl text-sm transition-all"
              style={{
                background: 'rgba(255,255,255,0.04)',
                border: '1px solid rgba(255,255,255,0.08)',
                color: '#6b7280',
              }}>
              Загрузить другой файл
            </button>
            <button
              onClick={onGoAnalytics}
              className="flex-1 py-2.5 rounded-xl text-sm font-medium transition-all"
              style={{
                background: 'rgba(99,102,241,0.12)',
                border: '1px solid rgba(99,102,241,0.2)',
                color: '#a5b4fc',
              }}>
              Перейти к аналитике →
            </button>
          </div>
        </div>
      )}


    </div>
  );
}
