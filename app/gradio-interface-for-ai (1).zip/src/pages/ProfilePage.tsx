import { useStore } from '../store/useStore';
import { User, Shield, Calendar, Radio } from 'lucide-react';

const CIVILIZATIONS = [
  'Kepler', 'Gliese', 'Cancri', 'HD', 'HIP', 'K2',
];

const CARD = { background: 'rgba(255,255,255,0.025)', border: '1px solid rgba(255,255,255,0.07)', borderRadius: 16 };

export function ProfilePage() {
  const session    = useStore((s) => s.session);
  const testResult = useStore((s) => s.analytics.testResult);

  const stats = [
    {
      label: 'Точность модели',
      value: testResult ? `${(testResult.accuracy * 100).toFixed(1)}%` : '—',
      color: '#4ade80',
    },
    {
      label: 'Потери (Loss)',
      value: testResult ? testResult.loss.toFixed(4) : '—',
      color: '#f59e0b',
    },
    {
      label: 'Известных цивилизаций',
      value: '10',
      color: '#a5b4fc',
    },
    {
      label: 'Роль',
      value: session?.role === 'admin' ? 'Администратор' : 'Пользователь',
      color: '#9ca3af',
    },
  ];

  const fields = [
    { label: 'Имя',        value: session?.firstName,              icon: User },
    { label: 'Фамилия',    value: session?.lastName,               icon: User },
    { label: 'Логин',      value: `@${session?.username}`,         icon: User },
    { label: 'Регистрация',value: new Date().toLocaleDateString('ru-RU'), icon: Calendar },
  ];

  return (
    <div className="space-y-5 max-w-xl">

      {/* Avatar + name */}
      <div className="p-6" style={CARD}>
        <div className="flex items-center gap-5 mb-6">
          <div className="w-16 h-16 rounded-2xl flex items-center justify-center flex-shrink-0 text-xl font-bold"
            style={{ background: 'rgba(99,102,241,0.12)', border: '1px solid rgba(99,102,241,0.18)', color: '#818cf8' }}>
            {session?.firstName?.[0]}{session?.lastName?.[0]}
          </div>
          <div>
            <h2 className="text-lg font-semibold" style={{ color: '#e2e4e9' }}>
              {session?.firstName} {session?.lastName}
            </h2>
            <p className="text-sm" style={{ color: '#4b5563' }}>@{session?.username}</p>
            <span className="inline-flex items-center gap-1.5 mt-1.5 px-2.5 py-1 rounded-full text-xs"
              style={session?.role === 'admin'
                ? { background: 'rgba(139,92,246,0.1)', color: '#a78bfa', border: '1px solid rgba(139,92,246,0.15)' }
                : { background: 'rgba(99,102,241,0.09)', color: '#818cf8', border: '1px solid rgba(99,102,241,0.14)' }}>
              <Shield className="w-3 h-3" />
              {session?.role === 'admin' ? 'Администратор' : 'Исследователь'}
            </span>
          </div>
        </div>

        {/* Info fields */}
        <div className="grid grid-cols-2 gap-3">
          {fields.map(({ label, value, icon: Icon }) => (
            <div key={label} className="rounded-xl px-4 py-3 flex items-center gap-3"
              style={{ background: 'rgba(255,255,255,0.03)' }}>
              <Icon className="w-4 h-4 flex-shrink-0" style={{ color: '#4b5563' }} />
              <div className="min-w-0">
                <p className="text-xs" style={{ color: '#4b5563' }}>{label}</p>
                <p className="text-sm font-medium truncate" style={{ color: '#c9cbd0' }}>{value}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-3">
        {stats.map(({ label, value, color }) => (
          <div key={label} className="rounded-xl p-4" style={CARD}>
            <p className="text-xs mb-1.5" style={{ color: '#4b5563' }}>{label}</p>
            <p className="text-xl font-semibold" style={{ color }}>{value}</p>
          </div>
        ))}
      </div>

      {/* Civilizations */}
      <div className="p-5" style={CARD}>
        <h3 className="text-sm font-medium mb-3 flex items-center gap-2" style={{ color: '#9ca3af' }}>
          <Radio className="w-4 h-4" style={{ color: '#4b5563' }} />
          Известные цивилизации
        </h3>
        <div className="flex flex-wrap gap-2">
          {CIVILIZATIONS.map((name, i) => (
            <span key={i} className="px-2.5 py-1 rounded-lg text-xs"
              style={{
                background: 'rgba(255,255,255,0.03)',
                border: '1px solid rgba(255,255,255,0.07)',
                color: '#6b7280',
              }}>
              {i}. {name}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
