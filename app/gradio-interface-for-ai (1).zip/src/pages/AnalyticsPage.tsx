import { useEffect, useState } from 'react';
import { useStore } from '../store/useStore';
import { api } from '../api/client';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  BarChart, Bar, Cell, PieChart, Pie,
} from 'recharts';
import { BarChart2, TrendingUp, Award, AlertCircle, Loader2 } from 'lucide-react';

// ── Muted palette ─────────────────────────────────────────────────────────────
const PALETTE = [
  '#6366f1','#8b5cf6','#64748b','#475569','#7c3aed',
  '#4f46e5','#6d28d9','#334155','#a78bfa','#94a3b8',
];

const CARD  = { background: 'rgba(255,255,255,0.025)', border: '1px solid rgba(255,255,255,0.07)', borderRadius: 16 };
const GRID  = { stroke: 'rgba(255,255,255,0.04)' };
const AXIS  = { stroke: 'rgba(255,255,255,0.12)', tick: { fontSize: 11, fill: 'rgba(255,255,255,0.3)' } };
const TT_BG = { background: '#161920', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 10, padding: '10px 14px', fontSize: 12 };

// ── Custom tooltips ───────────────────────────────────────────────────────────
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const AccTip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={TT_BG}>
      <p className="mb-1.5 font-medium" style={{ color: '#9ca3af', fontSize: 11 }}>Эпоха {label}</p>
      {payload.map((p: any) => (
        <p key={p.name} style={{ color: p.color }}>{p.name}: {(p.value * 100).toFixed(2)}%</p>
      ))}
    </div>
  );
};
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const LossTip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={TT_BG}>
      <p className="mb-1.5 font-medium" style={{ color: '#9ca3af', fontSize: 11 }}>Эпоха {label}</p>
      {payload.map((p: any) => (
        <p key={p.name} style={{ color: p.color }}>{p.name}: {Number(p.value).toFixed(4)}</p>
      ))}
    </div>
  );
};
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const BarTip = ({ active, payload }: any) => {
  if (!active || !payload?.length) return null;
  const d = payload[0].payload;
  return (
    <div style={TT_BG}>
      <p style={{ color: '#c9cbd0' }}>{d.className}</p>
      <p style={{ color: '#818cf8' }}>Класс {d.classId}: {d.count} записей</p>
    </div>
  );
};
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const AccBarTip = ({ active, payload }: any) => {
  if (!active || !payload?.length) return null;
  const d = payload[0].payload;
  return (
    <div style={TT_BG}>
      <p style={{ color: '#c9cbd0' }}>{d.className}</p>
      <p style={{ color: '#4ade80' }}>Точность: {(d.accuracy * 100).toFixed(1)}%</p>
    </div>
  );
};
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const PieTip = ({ active, payload }: any) => {
  if (!active || !payload?.length) return null;
  const d = payload[0].payload;
  return (
    <div style={TT_BG}>
      <p style={{ color: '#c9cbd0' }}>{d.className}</p>
      <p style={{ color: '#818cf8' }}>{d.count} записей</p>
    </div>
  );
};

// ── Section title ─────────────────────────────────────────────────────────────
function SectionTitle({ icon: Icon, title, subtitle }: { icon: React.ElementType; title: string; subtitle?: string }) {
  return (
    <div className="flex items-center gap-2.5 mb-5">
      <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
        style={{ background: 'rgba(99,102,241,0.08)', border: '1px solid rgba(99,102,241,0.12)' }}>
        <Icon className="w-4 h-4" style={{ color: '#6366f1' }} />
      </div>
      <div>
        <h3 className="text-sm font-semibold" style={{ color: '#c9cbd0' }}>{title}</h3>
        {subtitle && <p className="text-xs" style={{ color: '#4b5563' }}>{subtitle}</p>}
      </div>
    </div>
  );
}

// ── Main component ────────────────────────────────────────────────────────────
export function AnalyticsPage() {
  const { setAnalytics } = useStore();
  const { epochHistory, trainDistribution, testResult } = useStore((s) => s.analytics);
  const [tab, setTab] = useState<'accuracy' | 'loss'>('accuracy');
  const [fetching, setFetching] = useState(false);

  useEffect(() => {
    if (epochHistory.length > 0) return;
    setFetching(true);
    api.getTrainingAnalytics()
      .then((d) => setAnalytics({
        epochHistory: d.epochHistory,
        trainDistribution: d.trainDistribution,
        validDistribution: d.validDistribution,
      }))
      .catch(() => {})
      .finally(() => setFetching(false));
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const noTest = !testResult;

  if (fetching) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-6 h-6 animate-spin" style={{ color: '#4b5563' }} />
      </div>
    );
  }

  const TabBtn = ({ id, label }: { id: 'accuracy' | 'loss'; label: string }) => (
    <button onClick={() => setTab(id)}
      className="px-3.5 py-1.5 rounded-lg text-sm transition-all"
      style={tab === id
        ? { background: 'rgba(99,102,241,0.12)', border: '1px solid rgba(99,102,241,0.2)', color: '#a5b4fc' }
        : { border: '1px solid transparent', color: '#4b5563' }}>
      {label}
    </button>
  );

  return (
    <div className="space-y-6">

      {/* 1. Training history */}
      <div className="p-6" style={CARD}>
        <SectionTitle icon={TrendingUp} title="История обучения модели" subtitle="Зависимость метрик от количества эпох" />
        <div className="flex gap-2 mb-5">
          <TabBtn id="accuracy" label="Точность" />
          <TabBtn id="loss"     label="Потери" />
        </div>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            {tab === 'accuracy' ? (
              <LineChart data={epochHistory} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" {...GRID} />
                <XAxis dataKey="epoch" {...AXIS} />
                <YAxis {...AXIS} tickFormatter={(v) => `${(v * 100).toFixed(0)}%`} domain={[0, 1]} />
                <Tooltip content={<AccTip />} />
                <Legend wrapperStyle={{ color: 'rgba(255,255,255,0.4)', fontSize: 12 }} />
                <Line type="monotone" dataKey="trainAccuracy" name="Train Acc" stroke="#6366f1" strokeWidth={1.5} dot={false} activeDot={{ r: 3 }} />
                <Line type="monotone" dataKey="valAccuracy"   name="Val Acc"   stroke="#8b5cf6" strokeWidth={1.5} dot={false} activeDot={{ r: 3 }} strokeDasharray="5 3" />
              </LineChart>
            ) : (
              <LineChart data={epochHistory} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" {...GRID} />
                <XAxis dataKey="epoch" {...AXIS} />
                <YAxis {...AXIS} />
                <Tooltip content={<LossTip />} />
                <Legend wrapperStyle={{ color: 'rgba(255,255,255,0.4)', fontSize: 12 }} />
                <Line type="monotone" dataKey="loss"    name="Train Loss" stroke="#64748b" strokeWidth={1.5} dot={false} activeDot={{ r: 3 }} />
                <Line type="monotone" dataKey="valLoss" name="Val Loss"   stroke="#475569" strokeWidth={1.5} dot={false} activeDot={{ r: 3 }} strokeDasharray="5 3" />
              </LineChart>
            )}
          </ResponsiveContainer>
        </div>
      </div>

      {/* 2. Train class distribution */}
      <div className="p-6" style={CARD}>
        <SectionTitle icon={BarChart2} title="Распределение обучающей выборки" subtitle="Количество записей по цивилизациям (train)" />
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={trainDistribution} margin={{ top: 5, right: 20, left: 0, bottom: 55 }}>
              <CartesianGrid strokeDasharray="3 3" {...GRID} />
              <XAxis dataKey="className" {...AXIS} angle={-35} textAnchor="end" interval={0} />
              <YAxis {...AXIS} />
              <Tooltip content={<BarTip />} />
              <Bar dataKey="count" radius={[3, 3, 0, 0]}>
                {trainDistribution.map((_, i) => (
                  <Cell key={i} fill={PALETTE[i % PALETTE.length]} opacity={0.7} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* 3 & 4 — require test data */}
      {noTest ? (
        <div className="rounded-2xl p-10 text-center" style={CARD}>
          <AlertCircle className="w-10 h-10 mx-auto mb-3" style={{ color: '#374151' }} />
          <p className="text-sm font-medium" style={{ color: '#4b5563' }}>Тестовые данные не загружены</p>
          <p className="text-xs mt-1" style={{ color: '#374151' }}>
            Перейдите на страницу «Загрузка данных» и загрузите .npz файл
          </p>
        </div>
      ) : (
        <>
          {/* 3. Per-class accuracy */}
          <div className="p-6" style={CARD}>
            <SectionTitle icon={BarChart2} title="Точность по каждой цивилизации" subtitle="Результаты на тестовом наборе данных" />
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={testResult.perClassAccuracy} margin={{ top: 5, right: 20, left: 0, bottom: 55 }}>
                  <CartesianGrid strokeDasharray="3 3" {...GRID} />
                  <XAxis dataKey="className" {...AXIS} angle={-35} textAnchor="end" interval={0} />
                  <YAxis {...AXIS} tickFormatter={(v) => `${(v * 100).toFixed(0)}%`} domain={[0, 1]} />
                  <Tooltip content={<AccBarTip />} />
                  <Bar dataKey="accuracy" radius={[3, 3, 0, 0]}>
                    {testResult.perClassAccuracy.map((d, i) => (
                      <Cell key={i}
                        fill={d.accuracy >= 0.9 ? '#4ade80' : d.accuracy >= 0.75 ? '#f59e0b' : '#f87171'}
                        opacity={0.6}
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* 4. Top-5 classes – Pie + bar legend */}
          <div className="p-6" style={CARD}>
            <SectionTitle icon={Award} title="Топ-5 цивилизаций в тестовом наборе" subtitle="Наиболее часто встречающиеся классы" />
            <div className="flex flex-col lg:flex-row gap-8 items-center">
              {/* Pie */}
              <div className="h-56 w-full lg:w-72 flex-shrink-0">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={testResult.topClasses}
                      dataKey="count"
                      nameKey="className"
                      cx="50%"
                      cy="50%"
                      innerRadius={55}
                      outerRadius={85}
                      paddingAngle={2}
                    >
                      {testResult.topClasses.map((_, i) => (
                        <Cell key={i} fill={PALETTE[i % PALETTE.length]} opacity={0.78} />
                      ))}
                    </Pie>
                    <Tooltip content={<PieTip />} />
                  </PieChart>
                </ResponsiveContainer>
              </div>

              {/* Legend */}
              <div className="flex-1 w-full space-y-2">
                {testResult.topClasses.map((cls, i) => {
                  const total = testResult.topClasses.reduce((s, c) => s + c.count, 0);
                  const pct = total > 0 ? (cls.count / total * 100).toFixed(1) : '0';
                  return (
                    <div key={i} className="flex items-center gap-3">
                      <div className="w-2.5 h-2.5 rounded-full flex-shrink-0"
                        style={{ background: PALETTE[i % PALETTE.length] }} />
                      <span className="text-sm flex-1 truncate" style={{ color: '#9ca3af' }}>{cls.className}</span>
                      <div className="flex-1 h-1 rounded-full overflow-hidden"
                        style={{ background: 'rgba(255,255,255,0.05)' }}>
                        <div className="h-full rounded-full"
                          style={{ width: `${pct}%`, background: PALETTE[i % PALETTE.length], opacity: 0.6 }} />
                      </div>
                      <span className="text-xs w-16 text-right flex-shrink-0" style={{ color: '#4b5563' }}>
                        {cls.count} ({pct}%)
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
