/**
 * API client with automatic fallback to localStorage when backend is unavailable.
 * In Docker: nginx proxies /api/* → backend:5000
 * Standalone: all operations run locally in-browser
 */

import * as localDB from '../store/db';
import * as localInference from './localInference';

const BASE = import.meta.env.VITE_API_URL ?? '';

// ─── Backend availability probe ────────────────────────────────────────────────
let _backendAvailable: boolean | null = null;

async function probeBackend(): Promise<boolean> {
  if (_backendAvailable !== null) return _backendAvailable;
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 2000);
    const res = await fetch(`${BASE}/api/health`, { signal: ctrl.signal });
    clearTimeout(timer);
    _backendAvailable = res.ok;
  } catch {
    _backendAvailable = false;
  }
  return _backendAvailable;
}

// ─── HTTP helper ───────────────────────────────────────────────────────────────
async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE}/api${path}`, {
    headers: { 'Content-Type': 'application/json', ...(init?.headers ?? {}) },
    ...init,
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((json as any).error ?? `HTTP ${res.status}`);
  return json as T;
}

// ─── Exported types ────────────────────────────────────────────────────────────
export interface EpochRecord {
  epoch: number; trainAccuracy: number; valAccuracy: number; loss: number; valLoss: number;
}
export interface ClassDist { className: string; classId: number; count: number; }
export interface InferenceResult {
  accuracy: number;
  loss: number;
  totalSamples: number;
  perClassAccuracy: { className: string; classId: number; accuracy: number }[];
  topClasses: { className: string; classId: number; count: number }[];
  classDistribution: { className: string; classId: number; count: number }[];
  realInference: boolean;
}

type UserRow = { id: string; username: string; first_name: string; last_name: string; role: string; created_at: string; };
type LoginResult = { userId: string; username: string; firstName: string; lastName: string; role: string; };

// ─── API object ────────────────────────────────────────────────────────────────
export const api = {

  // ── Auth ─────────────────────────────────────────────────────────────────────
  login: async (username: string, password: string): Promise<LoginResult> => {
    const hasBackend = await probeBackend();
    if (hasBackend) {
      return request<LoginResult>('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ username, password }),
      });
    }
    // Local fallback
    const user = localDB.getUserByCredentials(username, password);
    if (!user) throw new Error('Неверный логин или пароль');
    return {
      userId: user.id,
      username: user.username,
      firstName: user.firstName,
      lastName: user.lastName,
      role: user.role,
    };
  },

  // ── Users ─────────────────────────────────────────────────────────────────────
  listUsers: async (): Promise<UserRow[]> => {
    const hasBackend = await probeBackend();
    if (hasBackend) return request<UserRow[]>('/users');
    return localDB.getAllUsers().map((u) => ({
      id: u.id,
      username: u.username,
      first_name: u.firstName,
      last_name: u.lastName,
      role: u.role,
      created_at: u.createdAt,
    }));
  },

  createUser: async (data: { username: string; password: string; firstName: string; lastName: string }): Promise<{ id: string }> => {
    const hasBackend = await probeBackend();
    if (hasBackend) {
      return request<{ id: string }>('/users', { method: 'POST', body: JSON.stringify(data) });
    }
    // Local fallback
    const existing = localDB.getUserByUsername(data.username);
    if (existing) throw new Error('Пользователь с таким логином уже существует');
    const id = crypto.randomUUID();
    localDB.createUser({
      id,
      username: data.username,
      password: data.password,
      firstName: data.firstName,
      lastName: data.lastName,
      role: 'user',
      createdAt: new Date().toISOString(),
    });
    return { id };
  },

  deleteUser: async (id: string): Promise<{ ok: boolean }> => {
    const hasBackend = await probeBackend();
    if (hasBackend) return request<{ ok: boolean }>(`/users/${id}`, { method: 'DELETE' });
    if (id === 'admin-001') throw new Error('Нельзя удалить администратора');
    localDB.deleteUser(id);
    return { ok: true };
  },

  // ── Analytics ─────────────────────────────────────────────────────────────────
  getTrainingAnalytics: async (): Promise<{
    epochHistory: EpochRecord[];
    trainDistribution: ClassDist[];
    validDistribution: ClassDist[];
  }> => {
    const hasBackend = await probeBackend();
    if (hasBackend) return request('/analytics/training');
    return localInference.getTrainingAnalytics();
  },

  // ── Inference ─────────────────────────────────────────────────────────────────
  runInference: async (file: File): Promise<InferenceResult> => {
    const hasBackend = await probeBackend();
    if (hasBackend) {
      const form = new FormData();
      form.append('file', file);
      const res = await fetch(`${BASE}/api/inference`, { method: 'POST', body: form });
      const json = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error((json as any).error ?? `HTTP ${res.status}`);
      return json as InferenceResult;
    }
    // Local fallback: parse npz in-browser
    return localInference.runLocalInference(file);
  },

  // ── Utility ───────────────────────────────────────────────────────────────────
  isBackendAvailable: () => probeBackend(),
};
