// This file is kept for compatibility but inference is now done server-side.
// The UploadPage calls api.runInference() directly.
export {};
