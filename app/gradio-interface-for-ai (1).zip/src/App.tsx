import { useEffect, useState } from 'react';
import { useStore } from './store/useStore';
import { initDB } from './store/db';
import { LoginPage } from './components/LoginPage';
import { Layout } from './components/Layout';
import { AdminUsersPage } from './pages/AdminUsersPage';
import { ProfilePage } from './pages/ProfilePage';
import { UploadPage } from './pages/UploadPage';
import { AnalyticsPage } from './pages/AnalyticsPage';

export function App() {
  const session = useStore((s) => s.session);
  const [page, setPage] = useState<string>('');

  useEffect(() => {
    initDB();
  }, []);

  useEffect(() => {
    if (!session) return;
    if (session.role === 'admin') {
      setPage('admin-users');
    } else {
      setPage('profile');
    }
  }, [session]);

  if (!session) {
    return <LoginPage />;
  }

  const renderPage = () => {
    switch (page) {
      case 'admin-users':
        return <AdminUsersPage />;
      case 'profile':
        return <ProfilePage />;
      case 'upload':
        return <UploadPage onGoAnalytics={() => setPage('analytics')} />;
      case 'analytics':
        return <AnalyticsPage />;
      default:
        return session.role === 'admin' ? <AdminUsersPage /> : <ProfilePage />;
    }
  };

  return (
    <Layout activePage={page} onNavigate={setPage}>
      {renderPage()}
    </Layout>
  );
}
