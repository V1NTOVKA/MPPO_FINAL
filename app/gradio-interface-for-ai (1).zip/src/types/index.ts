export type Role = 'admin' | 'user';

export interface User {
  id: string;
  username: string;
  password: string;
  firstName: string;
  lastName: string;
  role: Role;
  createdAt: string;
}

export interface Session {
  userId: string;
  username: string;
  role: Role;
  firstName: string;
  lastName: string;
}
