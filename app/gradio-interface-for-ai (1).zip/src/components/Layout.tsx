import { useState } from 'react';
import { useStore } from '../store/useStore';
import { Satellite, LogOut, User, BarChart2, Upload, Users, Menu, X, Shield, Radio } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
  activePage: string;
  onNavigate: (page: string) => void;
}

const BG   = '#111318';
const SIDE  = '#161920';
const BORD  = 'rgba(255,255,255,0.06)';
const TEXT  = '#9ca3af';
const TEXT2 = '#6b7280';

export function Layout({ children, activePage, onNavigate }: LayoutProps) {
  const { session, setSession } = useStore();
  const [menuOpen, setMenuOpen] = useState(false);

  const adminNav = [
    { id: 'admin-users', label: 'Пользователи', icon: Users },
  ];
  const userNav = [
    { id: 'profile',    label: 'Профиль',         icon: User },
    { id: 'upload',     label: 'Загрузка данных',  icon: Upload },
    { id: 'analytics',  label: 'Аналитика',        icon: BarChart2 },
  ];
  const navItems = session?.role === 'admin' ? adminNav : userNav;

  const activeLabel = navItems.find((n) => n.id === activePage)?.label ?? 'GalacticID';

  const NavBtn = ({ id, label, icon: Icon }: { id: string; label: string; icon: React.ElementType }) => {
    const active = activePage === id;
    return (
      <button
        onClick={() => { onNavigate(id); setMenuOpen(false); }}
        className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm transition-all"
        style={{
          background: active ? 'rgba(99,102,241,0.1)' : 'transparent',
          border: active ? '1px solid rgba(99,102,241,0.18)' : '1px solid transparent',
          color: active ? '#a5b4fc' : TEXT,
        }}>
        <Icon className="w-4 h-4 flex-shrink-0" />
        {label}
      </button>
    );
  };

  const Sidebar = () => (
    <aside className="fixed inset-y-0 left-0 z-40 w-60 flex flex-col"
      style={{ background: SIDE, borderRight: `1px solid ${BORD}` }}>

      {/* Logo */}
      <div className="flex items-center gap-3 px-5 py-4" style={{ borderBottom: `1px solid ${BORD}` }}>
        <div className="flex items-center justify-center w-8 h-8 rounded-lg flex-shrink-0"
          style={{ background: 'rgba(99,102,241,0.15)', border: '1px solid rgba(99,102,241,0.2)' }}>
          <Satellite className="w-4 h-4" style={{ color: '#818cf8' }} />
        </div>
        <div>
          <p className="text-sm font-semibold" style={{ color: '#c9cbd0' }}>GalacticID</p>
          <p className="text-xs" style={{ color: TEXT2 }}>2226 · Земля</p>
        </div>
      </div>

      {/* Signal */}
      <div className="px-5 py-2.5" style={{ borderBottom: `1px solid ${BORD}` }}>
        <div className="flex items-center gap-2">
          <Radio className="w-3 h-3" style={{ color: '#6b7280' }} />
          <span className="text-xs" style={{ color: '#6b7280' }}>Сигнал активен</span>
        </div>
      </div>

      {/* Role */}
      <div className="px-5 py-2.5" style={{ borderBottom: `1px solid ${BORD}` }}>
        <div className="flex items-center gap-2 rounded-lg px-2.5 py-1.5"
          style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)' }}>
          <Shield className="w-3.5 h-3.5 flex-shrink-0" style={{ color: '#6b7280' }} />
          <span className="text-xs" style={{ color: TEXT2 }}>
            {session?.role === 'admin' ? 'Администратор' : 'Пользователь'}
          </span>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-3 space-y-0.5 overflow-y-auto">
        {navItems.map((item) => <NavBtn key={item.id} {...item} />)}
      </nav>

      {/* User + Logout */}
      <div className="px-3 py-3" style={{ borderTop: `1px solid ${BORD}` }}>
        <div className="flex items-center gap-2.5 px-3 py-2 rounded-xl mb-2"
          style={{ background: 'rgba(255,255,255,0.03)' }}>
          <div className="w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-semibold"
            style={{ background: 'rgba(99,102,241,0.15)', color: '#818cf8' }}>
            {session?.firstName?.[0]}{session?.lastName?.[0]}
          </div>
          <div className="min-w-0">
            <p className="text-xs font-medium truncate" style={{ color: '#c9cbd0' }}>
              {session?.firstName} {session?.lastName}
            </p>
            <p className="text-xs truncate" style={{ color: TEXT2 }}>@{session?.username}</p>
          </div>
        </div>
        <button onClick={() => setSession(null)}
          className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-sm transition-all"
          style={{ color: '#9ca3af' }}
          onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = 'rgba(239,68,68,0.07)'; (e.currentTarget as HTMLButtonElement).style.color = '#fca5a5'; }}
          onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = 'transparent'; (e.currentTarget as HTMLButtonElement).style.color = '#9ca3af'; }}>
          <LogOut className="w-4 h-4" />
          Выйти
        </button>
      </div>
    </aside>
  );

  return (
    <div className="min-h-screen flex" style={{ background: BG }}>
      {/* Desktop sidebar */}
      <div className="hidden lg:block w-60 flex-shrink-0">
        <Sidebar />
      </div>

      {/* Mobile sidebar */}
      {menuOpen && (
        <>
          <div className="fixed inset-0 z-30 bg-black/50 lg:hidden"
            onClick={() => setMenuOpen(false)} />
          <div className="lg:hidden fixed left-0 top-0 bottom-0 z-40 w-60">
            <Sidebar />
          </div>
        </>
      )}

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top bar */}
        <header className="sticky top-0 z-20 px-5 py-3.5 flex items-center gap-3"
          style={{
            background: 'rgba(17,19,24,0.9)',
            backdropFilter: 'blur(12px)',
            borderBottom: `1px solid ${BORD}`,
          }}>
          <button className="lg:hidden transition-colors" style={{ color: TEXT }}
            onClick={() => setMenuOpen(!menuOpen)}>
            {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
          <div>
            <h2 className="text-sm font-semibold" style={{ color: '#c9cbd0' }}>{activeLabel}</h2>
            <p className="text-xs" style={{ color: TEXT2 }}>Система классификации радиосигналов</p>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 overflow-y-auto p-5 lg:p-8">
          {children}
        </main>
      </div>
    </div>
  );
}
