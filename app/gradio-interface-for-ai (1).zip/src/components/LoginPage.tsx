import { useState, useMemo } from 'react';
import { useStore } from '../store/useStore';
import { api } from '../api/client';
import { Satellite, Eye, EyeOff, Radio } from 'lucide-react';

// Deterministic stars
const STARS = Array.from({ length: 90 }, (_, i) => ({
  w: ((i * 37 + 11) % 18) / 10 + 1,
  top: ((i * 53 + 7) % 100),
  left: ((i * 79 + 13) % 100),
  op: ((i * 23 + 5) % 6) / 10 + 0.1,
  dur: 2 + ((i * 31) % 40) / 10,
  delay: ((i * 41) % 40) / 10,
}));

export function LoginPage() {
  const setSession = useStore((s) => s.setSession);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const stars = useMemo(() => STARS, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const user = await api.login(username.trim(), password);
      setSession({
        userId: user.userId,
        username: user.username,
        role: user.role as 'admin' | 'user',
        firstName: user.firstName,
        lastName: user.lastName,
      });
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Ошибка авторизации');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden"
      style={{ background: '#111318' }}>

      {/* Stars */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {stars.map((s, i) => (
          <div key={i} className="absolute rounded-full bg-white"
            style={{
              width: s.w, height: s.w,
              top: `${s.top}%`, left: `${s.left}%`,
              opacity: s.op,
              animation: `twinkle ${s.dur}s ease-in-out ${s.delay}s infinite`,
            }} />
        ))}
      </div>

      {/* Subtle glow blobs */}
      <div className="absolute top-1/4 left-1/3 w-80 h-80 rounded-full pointer-events-none"
        style={{ background: 'radial-gradient(circle, rgba(99,102,241,0.06) 0%, transparent 70%)' }} />
      <div className="absolute bottom-1/4 right-1/3 w-80 h-80 rounded-full pointer-events-none"
        style={{ background: 'radial-gradient(circle, rgba(71,85,105,0.08) 0%, transparent 70%)' }} />

      <div className="relative z-10 w-full max-w-sm px-4">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl mb-4"
            style={{ background: 'rgba(99,102,241,0.12)', border: '1px solid rgba(99,102,241,0.2)' }}>
            <Satellite className="w-8 h-8" style={{ color: '#818cf8' }} />
          </div>
          <h1 className="text-2xl font-semibold tracking-tight" style={{ color: '#e2e4e9' }}>
            GalacticID
          </h1>
          <p className="text-sm mt-1" style={{ color: '#6b7280' }}>
            Классификация радиосигналов · 2226
          </p>
          <div className="flex items-center justify-center gap-1.5 mt-2">
            <Radio className="w-3 h-3" style={{ color: '#6b7280' }} />
            <span className="text-xs" style={{ color: '#6b7280' }}>Сигнал принимается</span>
          </div>
        </div>

        {/* Card */}
        <div className="rounded-2xl p-7"
          style={{
            background: 'rgba(255,255,255,0.03)',
            border: '1px solid rgba(255,255,255,0.07)',
            boxShadow: '0 24px 48px rgba(0,0,0,0.4)',
          }}>
          <h2 className="text-base font-medium mb-5 text-center" style={{ color: '#c9cbd0' }}>
            Вход в систему
          </h2>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-medium mb-1.5" style={{ color: '#9ca3af' }}>
                Логин
              </label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Введите логин"
                required
                className="w-full px-3.5 py-2.5 rounded-xl text-sm outline-none transition-all"
                style={{
                  background: 'rgba(255,255,255,0.05)',
                  border: '1px solid rgba(255,255,255,0.09)',
                  color: '#e2e4e9',
                }}
                onFocus={e => (e.target.style.borderColor = 'rgba(129,140,248,0.4)')}
                onBlur={e => (e.target.style.borderColor = 'rgba(255,255,255,0.09)')}
              />
            </div>

            <div>
              <label className="block text-xs font-medium mb-1.5" style={{ color: '#9ca3af' }}>
                Пароль
              </label>
              <div className="relative">
                <input
                  type={showPass ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Введите пароль"
                  required
                  className="w-full px-3.5 py-2.5 pr-10 rounded-xl text-sm outline-none transition-all"
                  style={{
                    background: 'rgba(255,255,255,0.05)',
                    border: '1px solid rgba(255,255,255,0.09)',
                    color: '#e2e4e9',
                  }}
                  onFocus={e => (e.target.style.borderColor = 'rgba(129,140,248,0.4)')}
                  onBlur={e => (e.target.style.borderColor = 'rgba(255,255,255,0.09)')}
                />
                <button type="button" onClick={() => setShowPass(!showPass)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 transition-opacity"
                  style={{ color: '#6b7280' }}>
                  {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {error && (
              <div className="rounded-lg px-3.5 py-2.5 text-sm"
                style={{ background: 'rgba(220,38,38,0.1)', border: '1px solid rgba(220,38,38,0.2)', color: '#f87171' }}>
                {error}
              </div>
            )}

            <button type="submit" disabled={loading}
              className="w-full py-2.5 rounded-xl text-sm font-medium transition-all mt-1"
              style={{
                background: loading ? 'rgba(99,102,241,0.3)' : 'rgba(99,102,241,0.2)',
                border: '1px solid rgba(99,102,241,0.3)',
                color: loading ? '#9ca3af' : '#a5b4fc',
                cursor: loading ? 'not-allowed' : 'pointer',
              }}>
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <svg className="animate-spin w-4 h-4" viewBox="0 0 24 24" fill="none">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                  </svg>
                  Авторизация...
                </span>
              ) : 'Войти'}
            </button>
          </form>

          <div className="mt-5 pt-4" style={{ borderTop: '1px solid rgba(255,255,255,0.06)' }}>
            <p className="text-center text-xs" style={{ color: '#4b5563' }}>
              По умолчанию: <span style={{ color: '#6b7280' }}>admin / admin123</span>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
